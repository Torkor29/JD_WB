(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,26916,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(76350);let r=`
attribute vec2 a_pos;
void main() {
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`,o=`
precision highp float;
uniform vec2 u_res;
uniform float u_time;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    v += a * noise(p);
    p *= 2.05;
    a *= 0.5;
  }
  return v;
}

void main() {
  vec2 uv = gl_FragCoord.xy / u_res.xy;
  float aspect = u_res.x / max(u_res.y, 1.0);
  vec2 p = (uv - 0.5) * vec2(aspect, 1.0);

  float t = u_time * 0.22;

  float angle = 0.55;
  float ca = cos(angle);
  float sa = sin(angle);
  vec2 q = mat2(ca, -sa, sa, ca) * p;

  float flow = fbm(q * 1.35 + vec2(t * 0.7, -t * 0.45));
  float flow2 = fbm(q * 2.1 - vec2(t * 0.55, t * 0.35) + flow);

  float ribs = q.x * 18.0 + q.y * 7.0 + flow2 * 1.8;
  float flute = sin(ribs);
  float fluteMask = smoothstep(-0.15, 0.85, flute);
  float seam = pow(abs(flute), 0.35);

  float band = smoothstep(0.28, 0.72, flow2);
  float streak = smoothstep(0.55, 0.95, abs(sin(ribs * 0.35 + t)));

  vec3 paper = vec3(0.961, 0.973, 0.988);
  vec3 blue  = vec3(0.122, 0.369, 1.0);
  vec3 blue2 = vec3(0.231, 0.451, 1.0);
  vec3 deep  = vec3(0.039, 0.247, 0.800);
  vec3 white = vec3(1.0);

  vec3 col = paper;
  col = mix(col, white, 0.55 + 0.2 * flow);
  col = mix(col, mix(blue2, blue, streak), band * 0.72 * fluteMask);
  col = mix(col, deep, streak * band * 0.28);
  col += white * (1.0 - seam) * 0.12 * band;

  float glow = exp(-length(p * vec2(0.75, 1.1) - vec2(0.35, -0.15)) * 1.6);
  col = mix(col, mix(blue, white, 0.35), glow * 0.18);

  float g = hash(gl_FragCoord.xy + fract(u_time) * 40.0);
  col += (g - 0.5) * 0.035;

  gl_FragColor = vec4(col, 1.0);
}
`;function l(e,t,a){let i=e.createShader(t);return i?(e.shaderSource(i,a),e.compileShader(i),e.getShaderParameter(i,e.COMPILE_STATUS))?i:(e.deleteShader(i),null):null}function n(){return(0,t.jsxs)("div",{"aria-hidden":!0,className:"pointer-events-none absolute inset-0 z-10 overflow-hidden",children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-[radial-gradient(900px_circle_at_70%_10%,rgba(31,94,255,0.32),transparent_52%),linear-gradient(145deg,#F5F8FC_0%,#D6E4FF_42%,#EEF3FA_100%)]"}),(0,t.jsx)("div",{className:"absolute -left-1/4 top-1/4 h-[55%] w-[80%] animate-floaty rounded-full bg-accent/20 blur-3xl"}),(0,t.jsx)("div",{className:"absolute -right-1/4 bottom-0 h-[45%] w-[70%] rounded-full bg-accent/15 blur-3xl",style:{animation:"floaty 8s ease-in-out infinite reverse"}})]})}e.s(["LiquidHeroBackdrop",0,function(){let e=(0,a.useRef)(null),c=(0,i.usePrefersReducedMotion)(),s=(0,i.useIsMobile)(900),[f,u]=(0,a.useState)(!1),[d,v]=(0,a.useState)(!1);return((0,a.useEffect)(()=>{u(!0)},[]),(0,a.useEffect)(()=>{if(!f||c||s||d)return;let t=e.current;if(!t)return;let a=t.getContext("webgl",{alpha:!1,antialias:!1,premultipliedAlpha:!1,powerPreference:"high-performance"})||t.getContext("experimental-webgl");if(!a)return void v(!0);let i=l(a,a.VERTEX_SHADER,r),n=l(a,a.FRAGMENT_SHADER,o);if(!i||!n)return void v(!0);let u=a.createProgram();if(!u||(a.attachShader(u,i),a.attachShader(u,n),a.linkProgram(u),!a.getProgramParameter(u,a.LINK_STATUS)))return void v(!0);a.useProgram(u);let m=a.createBuffer();a.bindBuffer(a.ARRAY_BUFFER,m),a.bufferData(a.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),a.STATIC_DRAW);let h=a.getAttribLocation(u,"a_pos");a.enableVertexAttribArray(h),a.vertexAttribPointer(h,2,a.FLOAT,!1,0,0);let b=a.getUniformLocation(u,"u_res"),p=a.getUniformLocation(u,"u_time"),g=0,w=performance.now(),x=!0,_=e=>{e.preventDefault(),x=!1,cancelAnimationFrame(g),v(!0)};t.addEventListener("webglcontextlost",_);let A=()=>{let e=Math.min(window.devicePixelRatio||1,1.5),i=t.clientWidth,r=t.clientHeight;t.width=Math.max(1,Math.floor(i*e)),t.height=Math.max(1,Math.floor(r*e)),a.viewport(0,0,t.width,t.height),a.uniform2f(b,t.width,t.height)};A(),window.addEventListener("resize",A);let S=()=>{(x="visible"===document.visibilityState)&&E()};document.addEventListener("visibilitychange",S);let E=()=>{if(!x)return;let e=(performance.now()-w)/1e3;a.uniform1f(p,e),a.drawArrays(a.TRIANGLES,0,6),g=requestAnimationFrame(E)};return E(),()=>{x=!1,cancelAnimationFrame(g),window.removeEventListener("resize",A),document.removeEventListener("visibilitychange",S),t.removeEventListener("webglcontextlost",_),a.deleteProgram(u),a.deleteShader(i),a.deleteShader(n),a.deleteBuffer(m)}},[f,c,s,d]),!f||c||s||d)?(0,t.jsx)(n,{}):(0,t.jsx)("canvas",{ref:e,"aria-hidden":!0,className:"pointer-events-none absolute inset-0 z-10 h-full w-full"})}])},95029,function(e){e.n(e.i(26916))}]);