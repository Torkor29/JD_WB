(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,26916,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(76350);let r=`
attribute vec2 a_pos;
void main() {
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`,o=`
precision highp float;
uniform vec2 u_res;
uniform float u_time;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    v += a * noise(p);
    p *= 2.05;
    a *= 0.5;
  }
  return v;
}

void main() {
  vec2 uv = gl_FragCoord.xy / u_res.xy;
  float aspect = u_res.x / max(u_res.y, 1.0);
  vec2 p = (uv - 0.5) * vec2(aspect, 1.0);

  float t = u_time * 0.22;

  // Swirl / flow field
  float angle = 0.55;
  float ca = cos(angle);
  float sa = sin(angle);
  vec2 q = mat2(ca, -sa, sa, ca) * p;

  float flow = fbm(q * 1.35 + vec2(t * 0.7, -t * 0.45));
  float flow2 = fbm(q * 2.1 - vec2(t * 0.55, t * 0.35) + flow);

  // Fluted glass ribs (diagonal)
  float ribs = q.x * 18.0 + q.y * 7.0 + flow2 * 1.8;
  float flute = sin(ribs);
  float fluteMask = smoothstep(-0.15, 0.85, flute);
  float seam = pow(abs(flute), 0.35);

  // Chromatic liquid bands
  float band = smoothstep(0.28, 0.72, flow2);
  float streak = smoothstep(0.55, 0.95, abs(sin(ribs * 0.35 + t)));

  vec3 paper = vec3(0.961, 0.973, 0.988); // #F5F8FC
  vec3 blue  = vec3(0.122, 0.369, 1.0);    // #1F5EFF
  vec3 blue2 = vec3(0.231, 0.451, 1.0);    // #3B73FF
  vec3 deep  = vec3(0.039, 0.247, 0.800);  // #0A3FCC
  vec3 white = vec3(1.0);

  vec3 col = paper;
  col = mix(col, white, 0.55 + 0.2 * flow);
  col = mix(col, mix(blue2, blue, streak), band * 0.72 * fluteMask);
  col = mix(col, deep, streak * band * 0.28);
  col += white * (1.0 - seam) * 0.12 * band; // highlights on flutes

  // Soft vignette / top glow like reference
  float glow = exp(-length(p * vec2(0.75, 1.1) - vec2(0.35, -0.15)) * 1.6);
  col = mix(col, mix(blue, white, 0.35), glow * 0.18);

  // Film grain
  float g = hash(gl_FragCoord.xy + fract(u_time) * 40.0);
  col += (g - 0.5) * 0.035;

  gl_FragColor = vec4(col, 1.0);
}
`;function l(e,t,a){let i=e.createShader(t);return i?(e.shaderSource(i,a),e.compileShader(i),e.getShaderParameter(i,e.COMPILE_STATUS))?i:(e.deleteShader(i),null):null}e.s(["LiquidHeroBackdrop",0,function(){let e=(0,a.useRef)(null),n=(0,i.usePrefersReducedMotion)();return((0,a.useEffect)(()=>{if(n)return;let t=e.current;if(!t)return;let a=t.getContext("webgl",{alpha:!1,antialias:!1,premultipliedAlpha:!1})||t.getContext("experimental-webgl");if(!a)return;let i=l(a,a.VERTEX_SHADER,r),c=l(a,a.FRAGMENT_SHADER,o);if(!i||!c)return;let f=a.createProgram();if(!f||(a.attachShader(f,i),a.attachShader(f,c),a.linkProgram(f),!a.getProgramParameter(f,a.LINK_STATUS)))return;a.useProgram(f);let s=a.createBuffer();a.bindBuffer(a.ARRAY_BUFFER,s),a.bufferData(a.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),a.STATIC_DRAW);let u=a.getAttribLocation(f,"a_pos");a.enableVertexAttribArray(u),a.vertexAttribPointer(u,2,a.FLOAT,!1,0,0);let d=a.getUniformLocation(f,"u_res"),h=a.getUniformLocation(f,"u_time"),m=0,v=performance.now(),g=!0,p=()=>{let e=Math.min(window.devicePixelRatio||1,1.75),i=t.clientWidth,r=t.clientHeight;t.width=Math.max(1,Math.floor(i*e)),t.height=Math.max(1,Math.floor(r*e)),a.viewport(0,0,t.width,t.height),a.uniform2f(d,t.width,t.height)};p(),window.addEventListener("resize",p);let b=()=>{(g="visible"===document.visibilityState)&&(v=performance.now()-(performance.now()-v),w())};document.addEventListener("visibilitychange",b);let w=()=>{if(!g)return;let e=(performance.now()-v)/1e3;a.uniform1f(h,e),a.drawArrays(a.TRIANGLES,0,6),m=requestAnimationFrame(w)};return w(),()=>{g=!1,cancelAnimationFrame(m),window.removeEventListener("resize",p),document.removeEventListener("visibilitychange",b),a.deleteProgram(f),a.deleteShader(i),a.deleteShader(c),a.deleteBuffer(s)}},[n]),n)?(0,t.jsx)("div",{"aria-hidden":!0,className:"pointer-events-none absolute inset-0 z-10 bg-[radial-gradient(900px_circle_at_70%_15%,rgba(31,94,255,0.28),transparent_50%),linear-gradient(135deg,#F5F8FC_0%,#DCE8FF_45%,#F5F8FC_100%)]"}):(0,t.jsx)("canvas",{ref:e,"aria-hidden":!0,className:"pointer-events-none absolute inset-0 z-10 h-full w-full"})}])},95029,function(e){e.n(e.i(26916))}]);